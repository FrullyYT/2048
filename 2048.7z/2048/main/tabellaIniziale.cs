﻿namespace tabellaIniziale
{
    internal class Program
    {
        static int[,] tabellaIniziale()
        {
            Random rnd = new Random();
            int contatore = 0;

            int[,] tabellone = new int[4, 4];

            //riempie il tabellone di 0
            for (int i = 0; i < 3; i++)
            {
                for (int e = 0; e < 3; e++)
                {
                    tabellone[i, e] = 0;
                }
            }
            while (contatore == 2)
            {
                if (tabellone[rnd.Next(0, 4), rnd.Next(0, 4)] == 0)
                {
                    if (rnd.Next(1, 11) == 1)
                    {
                        tabellone[rnd.Next(0, 4), rnd.Next(0, 4)] = 4;
                    }
                    else
                    {
                        tabellone[rnd.Next(0, 4), rnd.Next(0, 4)] = 2;
                    }
                    contatore++;
                }
            }
            
            

            tabellone[rnd.Next(0, 4), rnd.Next(0, 4)] = 2;

            return tabellone;
        }
    }
}