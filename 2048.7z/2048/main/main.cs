﻿namespace main
{
    internal class Program
    {
        static void main(string[] args)
        {
            int[,] wow = tabellaIniziale();
        }
    }
}